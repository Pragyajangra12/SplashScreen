package com.example.splashscreen

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class mainscreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mainscreen)
    }
}